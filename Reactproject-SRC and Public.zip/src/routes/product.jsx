import { useLocation } from "react-router-dom";
import AdminNavigation from "../components/navs/adminnav";
import {
  Box,
  Button,
  CardMedia,
  TextField,
  ToggleButton,
  ToggleButtonGroup,
  Typography,
} from "@mui/material";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const Product = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [quantity, setQuantity] = useState(1);
  const searchParams = new URLSearchParams(location.search);
  const id = searchParams.get("productId");
  const [platform, setPlatform] = useState("all");
  const handleChange = (event, newPlatform) => {
    if (newPlatform !== null) {
      setPlatform(newPlatform);
    }
  };
  const [categories, setCategories] = useState([]);
  const getCategories = async () => {
    const response = await fetch(
      "http://localhost:8080/api/products/categories"
    );
    const data = await response.json();
    setCategories(data);
  };

  useEffect(() => {
    getCategories();
  }, []);
  const [productDetails, setProductDetails] = useState();
  useEffect(() => {
    console.log(id);
    if (id) {
      fetch(`http://localhost:8080/api/products/${id}`)
        .then(res => res.json())
        .then(data => {
          console.log(data);
          setProductDetails(data);
        });
    }
  }, [id]);
  if (!id) {
    return (
      <div>
        <h1>Invalid Product ID</h1>
      </div>
    );
  }
  if (!productDetails) {
    return <></>;
  }
  return (
    <>
      <AdminNavigation />
      <Box marginTop={4} display="flex" justifyContent="center" width="100%">
        <ToggleButtonGroup
          color="primary"
          value={platform}
          exclusive
          onChange={handleChange}
          aria-label="Platform"
        >
          {categories.map(category => {
            return (
              <ToggleButton value={category.toLowerCase()}>
                {category}
              </ToggleButton>
            );
          })}
        </ToggleButtonGroup>
      </Box>
      <Box
        paddingX={10}
        display={"flex"}
        justifyContent={"center"}
        marginTop={12}
      >
        <Box width={"50vw"} display={"flex"} justifyContent={"center"}>
          <img
            src={productDetails.imageUrl}
            alt="IMAGE"
            style={{ minWidth: "200px", maxWidth: "400px" }}
          />
        </Box>
        <Box width={"50vw"}>
          <Typography fontSize={"2rem"}>{productDetails.name}</Typography>
          <Box display={"flex"}>
            <p>Category: &nbsp;</p>
            <p style={{ fontWeight: "bold" }}>{productDetails.category}</p>
          </Box>
          <p style={{ fontStyle: "italic" }}>{productDetails.description}</p>
          <Typography fontSize={"2rem"} color={"red"}>
            $ {productDetails.price}
          </Typography>
          <TextField
            margin="normal"
            required
            value={quantity}
            onChange={e => setQuantity(e.target.value)}
            id="quantity"
            label="Quantity"
            name="quantity"
          />
          <br />
          <Button
            onClick={() =>
              navigate(`/order?productId=${id}&quantity=${quantity}`)
            }
            variant="contained"
            sx={{ backgroundColor: "#3f51b5" }}
          >
            place order
          </Button>
        </Box>
      </Box>
    </>
  );
};
export default Product;
