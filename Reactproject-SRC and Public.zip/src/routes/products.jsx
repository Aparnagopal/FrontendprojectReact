import {
  Box,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  ToggleButton,
  ToggleButtonGroup,
} from "@mui/material";
import AdminNavigation from "../components/navs/adminnav";
import { useEffect, useState } from "react";
import ImgMediaCard from "../components/common/NonAdminCard";
import EditProduct from "../components/common/EditProduct";

const ProductsPage = () => {
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState("default");
  const [products, setProducts] = useState([]);
  const [productToEdit, setProductToEdit] = useState(null);
  const [useEdit, setUseEdit] = useState(false);

  const handleChangeSortBy = async event => {
    const response = await fetch("http://localhost:8080/api/products");
    let data = await response.json();
    if (event.target.value === "ltoh") {
      data = data.sort((a, b) => a.price - b.price);
    } else if (event.target.value === "htol") {
      data = data.sort((a, b) => b.price - a.price);
    }
    setProducts(data);
    setSortBy(event.target.value);
  };

  const [categories, setCategories] = useState([]);
  const getCategories = async () => {
    const response = await fetch(
      "http://localhost:8080/api/products/categories"
    );
    const data = await response.json();
    setCategories(data);
  };
  const getProducts = async () => {
    const response = await fetch("http://localhost:8080/api/products");
    const data = await response.json();
    console.log(data);
    setProducts(data);
  };
  useEffect(() => {
    getCategories();
    getProducts();
  }, [useEdit]);
  const [platform, setPlatform] = useState("all");
  const handleChange = async (event, newPlatform) => {
    const products = await fetch(`http://localhost:8080/api/products`);
    let data = await products.json();

    if (newPlatform !== "all") {
      data = data.filter(product => {
        return product.category === newPlatform;
      });
    }
    console.log(data);
    setProducts(data);
    if (newPlatform !== null) {
      setPlatform(newPlatform);
    }
  };
  if (!localStorage.getItem("token")) {
    return (
      <div>
        <h1>Unauthorized</h1>
      </div>
    );
  }
  if (useEdit) {
    return (
      <>
        <AdminNavigation />
        <Box marginTop={4} display="flex" justifyContent="center" width="100%">
          <ToggleButtonGroup
            color="primary"
            value={platform}
            exclusive
            onChange={handleChange}
            aria-label="Platform"
          >
            <ToggleButton value={"all"}>All</ToggleButton>
            {categories.map(category => {
              return (
                <ToggleButton value={category.toLowerCase()}>
                  {category}
                </ToggleButton>
              );
            })}
          </ToggleButtonGroup>
        </Box>
        <EditProduct productToEdit={productToEdit} setUseEdit={setUseEdit} />
      </>
    );
  }
  return (
    <>
      <AdminNavigation setSearch={setSearch} search={search} />
      <Box marginTop={4} display="flex" justifyContent="center" width="100%">
        <ToggleButtonGroup
          color="primary"
          value={platform}
          exclusive
          onChange={handleChange}
          aria-label="Platform"
        >
          <ToggleButton value={"all"}>All</ToggleButton>

          {categories.map(category => {
            return (
              <ToggleButton value={category.toLowerCase()}>
                {category}
              </ToggleButton>
            );
          })}
        </ToggleButtonGroup>
      </Box>
      <Box width={200} marginLeft={12}>
        <FormControl fullWidth>
          <InputLabel id="demo-simple-select-label">Sort By</InputLabel>
          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            value={sortBy}
            label="Sort By:"
            onChange={handleChangeSortBy}
          >
            <MenuItem value={"default"}>Default</MenuItem>
            <MenuItem value={"ltoh"}>Price: Low To High</MenuItem>
            <MenuItem value={"htol"}>Price: High To Low</MenuItem>
            <MenuItem value={"newest"}>Newest</MenuItem>
          </Select>
        </FormControl>
      </Box>
      <Box
        paddingY={4}
        paddingX={8}
        sx={{
          display: "flex",
          gap: 10,
          justifyContent: "space-evenly",
          flexWrap: "wrap",
        }}
      >
        {search == "" &&
          products.map(product => {
            return (
              <ImgMediaCard
                setProductToEdit={setProductToEdit}
                setUseEdit={setUseEdit}
                product={product}
              />
            );
          })}
        {search != "" &&
          products
            .filter(product => {
              return product.name.toLowerCase().includes(search.toLowerCase());
            })
            .map(product => {
              return (
                <ImgMediaCard
                  setProductToEdit={setProductToEdit}
                  setUseEdit={setUseEdit}
                  product={product}
                />
              );
            })}
      </Box>
    </>
  );
};
export default ProductsPage;
