import * as React from "react";

import DefaultNavigation from "../components/navs/defaultnav";
import SignUp from "../components/signup";

export default function Signup() {
  return (
    <>
      <DefaultNavigation />
      <SignUp />
    </>
  );
}
