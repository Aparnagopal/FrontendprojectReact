import { useLocation, useNavigate } from "react-router-dom";
import AdminNavigation from "../components/navs/adminnav";
import {
  Box,
  Button,
  CardMedia,
  TextField,
  ToggleButton,
  ToggleButtonGroup,
  Typography,
} from "@mui/material";
import { useEffect, useState } from "react";
import ProgressBar from "../components/common/PurchaseProgress";
import AddressSelection from "../components/common/AddressSelection";
import ConfirmOrder from "../components/common/ConfirmOrder";
const OrderPage = () => {
  const navigate = useNavigate();
  const [selectedAddress, setSelectedAddress] = useState();
  const [pageState, setPageState] = useState(1);
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const id = searchParams.get("productId");
  const [quantity, setQuantity] = useState(searchParams.get("quantity") || 1);
  const [productDetails, setProductDetails] = useState();

  useEffect(() => {
    console.log(id);
    if (id) {
      fetch(`http://localhost:8080/api/products/${id}`)
        .then(res => res.json())
        .then(data => {
          console.log(data);
          setProductDetails(data);
        });
    }
  }, [id]);
  if (!id) {
    return (
      <div>
        <h1>Invalid Product ID</h1>
      </div>
    );
  }
  if (!productDetails) {
    return <></>;
  }
  return (
    <>
      <AdminNavigation />
      <Box paddingY={6} paddingX={24}>
        <ProgressBar pageState={pageState} />
      </Box>
      {pageState == 1 && (
        <Box
          paddingX={10}
          display={"flex"}
          justifyContent={"center"}
          marginTop={12}
        >
          <Box width={"50vw"} display={"flex"} justifyContent={"center"}>
            <img
              src={productDetails.imageUrl}
              alt="IMAGE"
              style={{ minWidth: "200px", maxWidth: "400px" }}
            />
          </Box>
          <Box width={"50vw"}>
            <Typography fontSize={"2rem"}>{productDetails.name}</Typography>
            <Box display={"flex"}>
              <p>Category: &nbsp;</p>
              <p style={{ fontWeight: "bold" }}>{productDetails.category}</p>
            </Box>
            <p style={{ fontStyle: "italic" }}>{productDetails.description}</p>
            <Typography fontSize={"2rem"} color={"red"}>
              Total Price: $ {productDetails.price * quantity}
            </Typography>
            <Box marginY={4}>
              <Button
                onClick={() => {
                  navigate(`/product/?productId=${id}`);
                }}
                variant="contained"
                sx={{ backgroundColor: "#3f51b5" }}
              >
                Back
              </Button>
              <Button
                variant="contained"
                sx={{ backgroundColor: "#3f51b5", marginLeft: 1 }}
                onClick={() => setPageState(2)}
              >
                Next
              </Button>
            </Box>
          </Box>
        </Box>
      )}
      {pageState == 2 && (
        <AddressSelection
          setSelectedAddress={setSelectedAddress}
          selectedAddress={selectedAddress}
          setPageState={setPageState}
        />
      )}
      {pageState == 3 && (
        <ConfirmOrder
          productDetails={productDetails}
          quantity={quantity}
          selectedAddress={selectedAddress}
          setPageState={setPageState}
        />
      )}
    </>
  );
};
export default OrderPage;
