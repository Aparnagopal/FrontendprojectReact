import * as React from "react";

import DefaultNavigation from "../components/navs/defaultnav";
import SignIn from "../components/signin";

export default function Signin() {
  return (
    <>
      <DefaultNavigation />
      <SignIn />
    </>
  );
}
