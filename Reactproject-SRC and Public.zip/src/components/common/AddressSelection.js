import {
  Box,
  Button,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Typography,
} from "@mui/material";
import { useEffect, useState } from "react";

const AddressSelection = ({
  setPageState,
  selectedAddress,
  setSelectedAddress,
}) => {
  const [address, setAddress] = useState("");
  const [name, setName] = useState("");
  const [contact, setContact] = useState("");
  const [street, setStreet] = useState("");
  const [city, setCity] = useState("");
  const [pincode, setPincode] = useState("");
  const [state, setState] = useState("");
  const [country, setCountry] = useState("");
  const [landmark, setLandmark] = useState("");
  const [addresses, setAddresses] = useState([]);
  const getAddresses = async () => {
    const response = await fetch("http://localhost:8080/api/addresses", {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
    });
    const data = await response.json();
    console.log(data);
    setAddresses(data);
  };
  useEffect(() => {
    getAddresses();
  }, []);
  return (
    <Box
      display={"flex"}
      justifyContent={"center"}
      flexDirection={"column"}
      alignItems={"center"}
    >
      <FormControl
        sx={{ width: "100%", maxWidth: "300px" }}
        display={"flex"}
        justifyContent={"center"}
      >
        <InputLabel id="demo-simple-select-label">Select Address</InputLabel>

        <Select
          labelId="demo-simple-select-label"
          id="demo-simple-select"
          value={address}
          label="Sort By:"
          onChange={e => setAddress(e.target.value)}
        >
          {addresses &&
            addresses.map(address => {
              return (
                <MenuItem
                  onClick={() => {
                    setSelectedAddress(address);
                  }}
                  value={address.id}
                >
                  {address.name} - {address.street} - {address.city} -{" "}
                  {address.state} - {address.pincode}
                </MenuItem>
              );
            })}
          {/* <MenuItem value={"ltoh"}>Price: Low To High</MenuItem> */}
          {/* <MenuItem value={"htol"}>Price: High To Low</MenuItem> */}
          {/* <MenuItem value={"newest"}>Newest</MenuItem> */}
        </Select>
      </FormControl>
      <Typography sx={{ marginTop: 4 }}>-OR-</Typography>
      <Typography sx={{ marginTop: 4 }} fontSize={"1.2rem"}>
        Add Address
      </Typography>
      <TextField
        margin="normal"
        required
        id="name"
        value={name}
        onChange={e => setName(e.target.value)}
        label="Name"
        name="name"
        sx={{ width: "100%", maxWidth: "500px" }}
      />
      <TextField
        margin="normal"
        required
        value={contact}
        onChange={e => setContact(e.target.value)}
        id="contact"
        label="Contact Number"
        name="contact"
        type="number"
        sx={{ width: "100%", maxWidth: "500px" }}
      />
      <TextField
        margin="normal"
        value={street}
        onChange={e => setStreet(e.target.value)}
        required
        id="street"
        label="Street"
        sx={{ width: "100%", maxWidth: "500px" }}
        name="street"
      />
      <TextField
        margin="normal"
        value={city}
        onChange={e => setCity(e.target.value)}
        required
        id="city"
        label="City"
        name="city"
        sx={{ width: "100%", maxWidth: "500px" }}
      />
      <TextField
        margin="normal"
        required
        value={state}
        onChange={e => setState(e.target.value)}
        id="state"
        label="State"
        sx={{ width: "100%", maxWidth: "500px" }}
        name="state"
      />
      <TextField
        margin="normal"
        required
        value={landmark}
        onChange={e => setLandmark(e.target.value)}
        id="landmark"
        label="Landmark"
        sx={{ width: "100%", maxWidth: "500px" }}
        name="landmark"
      />
      <TextField
        margin="normal"
        required
        value={pincode}
        onChange={e => setPincode(e.target.value)}
        id="zip"
        label="Zip Code"
        sx={{ width: "100%", maxWidth: "500px" }}
        name="zip"
      />
      <Button
        variant="contained"
        sx={{
          backgroundColor: "#3f51b5",
          marginTop: 4,
          width: "100%",
          maxWidth: "500px",
        }}
        onClick={async () => {
          if (
            name === "" ||
            contact === "" ||
            street === "" ||
            city === "" ||
            state === "" ||
            pincode === "" ||
            landmark === ""
          ) {
            alert("Please fill all the fields");
          } else {
            const address = {
              name,
              contactNumber: contact,
              city,
              landmark,
              street,
              state,
              zipcode: pincode,
              user: "64afb78b189115150342912c",
            };
            // add address using post
            try {
              const response = await fetch(
                "http://localhost:8080/api/addresses",
                {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${localStorage.getItem("token")}`,
                  },
                  body: JSON.stringify(address),
                }
              );
              getAddresses();
            } catch (err) {
              console.log(err);
            }
          }
        }}
      >
        Save Address
      </Button>
      <Box marginY={4}>
        <Button
          onClick={() => setPageState(1)}
          variant="contained"
          sx={{ backgroundColor: "#3f51b5" }}
        >
          Back
        </Button>
        <Button
          variant="contained"
          sx={{ backgroundColor: "#3f51b5", marginLeft: 1 }}
          onClick={() => {
            if (selectedAddress) {
              setPageState(3);
            } else {
              alert("Please select an address");
            }
          }}
        >
          Next
        </Button>
      </Box>
    </Box>
  );
};
export default AddressSelection;
