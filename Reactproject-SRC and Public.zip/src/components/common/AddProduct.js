import {
  Box,
  Button,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  ToggleButton,
  ToggleButtonGroup,
  Typography,
} from "@mui/material";
import { useEffect, useState } from "react";
import AdminNavigation from "../navs/adminnav";
import { useNavigate } from "react-router-dom";

const AddProduct = () => {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [category, setCategory] = useState("");
  const [manufacturer, setManufacturer] = useState("");
  const [availableItems, setAvailableItems] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");
  const [image, setImage] = useState("");
  const [categories, setCategories] = useState([]);

  const getCategories = async () => {
    const response = await fetch(
      "http://localhost:8080/api/products/categories"
    );
    const data = await response.json();
    setCategories(data);
  };

  useEffect(() => {
    getCategories();
  }, []);
  if (!localStorage.getItem("token")) {
    return (
      <div>
        <h1>Unauthorized</h1>
      </div>
    );
  }
  return (
    <>
      <AdminNavigation />
      <Box marginTop={4} display="flex" justifyContent="center" width="100%">
        <ToggleButtonGroup
          color="primary"
          //   value={platform}
          exclusive
          //   onChange={handleChange}
          aria-label="Platform"
        >
          {categories.map(category => {
            return (
              <ToggleButton value={category.toLowerCase()}>
                {category}
              </ToggleButton>
            );
          })}
        </ToggleButtonGroup>
      </Box>
      <Box
        display={"flex"}
        justifyContent={"center"}
        flexDirection={"column"}
        alignItems={"center"}
      >
        <Typography sx={{ marginTop: 4 }} fontSize={"1.2rem"}>
          Add Product
        </Typography>
        <TextField
          margin="normal"
          required
          value={name}
          onChange={e => setName(e.target.value)}
          id="name"
          label="Name"
          name="name"
          sx={{ width: "100%", maxWidth: "500px" }}
        />

        <FormControl
          sx={{ width: "100%", maxWidth: "500px" }}
          display={"flex"}
          justifyContent={"center"}
        >
          <InputLabel id="demo-simple-select-label">Select Category</InputLabel>

          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            value={category}
            label="Sort By:"
            onChange={e => setCategory(e.target.value)}
          >
            {categories.map(category => {
              return (
                <MenuItem value={category.toLowerCase()}>{category}</MenuItem>
              );
            })}

            {/* <MenuItem value={"ltoh"}>Price: Low To High</MenuItem> */}
            {/* <MenuItem value={"htol"}>Price: High To Low</MenuItem> */}
            {/* <MenuItem value={"newest"}>Newest</MenuItem> */}
          </Select>
        </FormControl>
        <TextField
          margin="normal"
          required
          value={manufacturer}
          onChange={e => setManufacturer(e.target.value)}
          id="manufacturer"
          label="Manufacturer"
          name="manufacturer"
          sx={{ width: "100%", maxWidth: "500px" }}
        />
        <TextField
          margin="normal"
          required
          value={availableItems}
          onChange={e => setAvailableItems(e.target.value)}
          id="available-items"
          label="Available Items"
          sx={{ width: "100%", maxWidth: "500px" }}
          name="available-items"
        />
        <TextField
          margin="normal"
          required
          value={price}
          onChange={e => setPrice(e.target.value)}
          id="price"
          label="Price"
          sx={{ width: "100%", maxWidth: "500px" }}
          name="price"
          type="number"
        />
        <TextField
          margin="normal"
          required
          value={image}
          onChange={e => setImage(e.target.value)}
          id="image-url"
          label="Image URL"
          sx={{ width: "100%", maxWidth: "500px" }}
          name="image-url"
        />
        <TextField
          margin="normal"
          required
          value={description}
          onChange={e => setDescription(e.target.value)}
          id="product-description"
          label="Product Description"
          sx={{ width: "100%", maxWidth: "500px" }}
          name="product-description"
        />
        <Box sx={{ width: "100%", maxWidth: "500px" }} marginY={4}>
          <Button
            onClick={async () => {
              try {
                const response = await fetch(
                  "http://localhost:8080/api/products",
                  {
                    method: "POST",
                    headers: {
                      "Content-Type": "application/json",
                      Authorization: "Bearer " + localStorage.getItem("token"),
                    },
                    body: JSON.stringify({
                      name,
                      category,
                      manufacturer,
                      availableItems,
                      price,
                      description,
                      imageUrl: image,
                    }),
                  }
                );
                if (!response.ok) throw new Error("Something went wrong");
                else {
                  alert("Product Added Successfully");
                  navigate("/products");
                }
              } catch (err) {
                console.log(err);
                alert("Error Adding Product");
              }
            }}
            variant="contained"
            sx={{
              backgroundColor: "#3f51b5",
              width: "100%",
              maxWidth: "500px",
            }}
          >
            Add Product
          </Button>
        </Box>
      </Box>
    </>
  );
};
export default AddProduct;
