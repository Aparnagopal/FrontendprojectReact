import { Box, Button, Typography } from "@mui/material";
import { useNavigate } from "react-router-dom";

const ConfirmOrder = ({
  setPageState,
  selectedAddress,
  productDetails,
  quantity,
}) => {
  const navigate = useNavigate();
  return (
    <>
      <Box display={"flex"} marginX={30} padding={5}>
        <Box
          sx={{
            border: "1px solid gray",
            padding: 5,
          }}
          flex={2}
        >
          <Typography fontSize={"2rem"}>{productDetails.name}</Typography>
          <Typography>
            Quantity : <b>{quantity}</b>
          </Typography>
          <Typography>
            Category:
            <b>{productDetails.category}</b>
          </Typography>
          <Typography>{productDetails.description}</Typography>

          <Typography sx={{ marginTop: 5 }} fontSize={"2rem"} color={"red"}>
            Total Price: $ {productDetails.price * quantity}
          </Typography>
        </Box>
        <Box
          sx={{
            border: "1px solid gray",
            padding: 5,
          }}
          flex={1}
        >
          <Typography fontSize={"2rem"}>Address Details</Typography>
          <Typography>{selectedAddress.name}</Typography>
          <Typography>Contact No. {selectedAddress.contactNumber}</Typography>
          <Typography>
            {selectedAddress.street}, {selectedAddress.city}
          </Typography>
          <Typography>{selectedAddress.state}</Typography>
          <Typography>{selectedAddress.zipcode}</Typography>
        </Box>
      </Box>
      <Box display={"flex"} justifyContent={"center"} marginX={30} padding={5}>
        <Button
          onClick={() => setPageState(2)}
          variant="contained"
          sx={{ color: "#3f51b5", backgroundColor: "white" }}
        >
          Back
        </Button>
        <Button
          variant="contained"
          sx={{ backgroundColor: "#3f51b5", marginLeft: 1 }}
          onClick={async () => {
            const order = {
              product: productDetails.id,
              quantity: quantity,
              address: selectedAddress.id,
              user: "64afb78b189115150342912c",
            };
            // place order using post
            try {
              const response = await fetch("http://localhost:8080/api/orders", {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${localStorage.getItem("token")}`,
                },
                body: JSON.stringify(order),
              });
              if (response.status === 200) {
                alert("Order Placed Successfully");
              }
            } catch (err) {
              console.log(err);
            }
            navigate("/products");
          }}
        >
          Place Order
        </Button>
      </Box>
    </>
  );
};
export default ConfirmOrder;
