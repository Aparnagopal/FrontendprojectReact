import React from "react";
import LinearProgress from "@mui/material/LinearProgress";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { styled } from "@mui/material/styles";
import { CheckCircleOutline, CheckCircleRounded } from "@mui/icons-material";

const ProgressContainer = styled(Box)({
  display: "flex",
  alignItems: "center",
});

const ProgressLabel = styled(Typography)({
  marginRight: "8px",
});

const Circle = styled("div")(({ theme }) => ({
  width: "16px",
  height: "16px",
  borderRadius: "50%",
  //   backgroundColor: "#3f51b5",
  border: "1px solid gray",
  marginRight: "8px",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  padding: "3px",
}));

const Line = styled("div")(({ theme }) => ({
  height: "1px",
  backgroundColor: "gray",
  flex: 1,
  marginRight: "8px",
}));

const ProgressBar = ({ pageState }) => {
  const value1 = 30;
  const value2 = 60;
  const value3 = 100;

  return (
    <ProgressContainer>
      {/* Tick icon from mui */}
      {pageState === 1 ? (
        <Circle sx={{ backgroundColor: "#3f51b5", color: "white" }}>1</Circle>
      ) : (
        <Circle>
          <CheckCircleRounded
            sx={{
              borderRadius: "100%",
              backgroundColor: "white",
              color: "#3f51b5",
            }}
          />
        </Circle>
      )}
      <ProgressLabel>Items</ProgressLabel>
      <Line />
      <LinearProgress variant="determinate" value={value1} />
      {pageState > 2 ? (
        <Circle>
          <CheckCircleRounded
            sx={{
              borderRadius: "100%",
              backgroundColor: "white",
              color: "#3f51b5",
            }}
          />
        </Circle>
      ) : pageState === 2 ? (
        <Circle sx={{ backgroundColor: "#3f51b5", color: "white" }}>2</Circle>
      ) : (
        <Circle>2</Circle>
      )}
      <ProgressLabel>Select Address</ProgressLabel>
      <Line />
      <LinearProgress variant="determinate" value={value2 - value1} />
      {pageState > 3 ? (
        <Circle>
          <CheckCircleRounded
            sx={{
              borderRadius: "100%",
              backgroundColor: "white",
              color: "#3f51b5",
            }}
          />
        </Circle>
      ) : pageState === 3 ? (
        <Circle sx={{ backgroundColor: "#3f51b5", color: "white" }}>3</Circle>
      ) : (
        <Circle>3</Circle>
      )}
      <ProgressLabel>Confirm Order</ProgressLabel>
      <LinearProgress variant="determinate" value={value3 - value2} />
    </ProgressContainer>
  );
};

export default ProgressBar;
