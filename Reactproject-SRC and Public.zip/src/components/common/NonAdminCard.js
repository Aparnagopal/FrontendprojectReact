import * as React from "react";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import { Box, IconButton } from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import { redirect } from "react-router-dom";
import { red } from "@mui/material/colors";
import { useNavigate } from "react-router-dom";
import { Modal } from "@mui/material";
import DeleteModal from "./DeleteModal";
const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};
export default function ImgMediaCard({
  product,
  isAdmin,
  setUseEdit,
  setProductToEdit,
}) {
  const navigate = useNavigate();
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const [selectedProduct, setSelectedProduct] = React.useState(null);
  return (
    <Card sx={{ maxWidth: 275, minWidth: 250 }}>
      <CardMedia
        component="img"
        alt="green iguana"
        height="140"
        image={product.imageUrl}
      />
      <CardContent>
        <Box display={"flex"} justifyContent={"space-between"}>
          <Typography gutterBottom variant="h5" component="div">
            {product.name}
          </Typography>
          <Typography gutterBottom variant="h5" component="div">
            ${product.price}
          </Typography>
        </Box>
        <Typography variant="body2" color="text.secondary">
          {product.description}
        </Typography>
      </CardContent>
      <Box display={"flex"} justifyContent={"space-between"}>
        <CardActions>
          <Button
            sx={{ backgroundColor: "#3f51b5", color: "white" }}
            size="small"
            onClick={() => navigate(`/product?productId=${product.id}`)}
          >
            Buy
          </Button>
        </CardActions>
        {localStorage.getItem("role") == "admin" && (
          <CardActions>
            <IconButton
              onClick={() => {
                setProductToEdit(product);
                setUseEdit(true);
              }}
              aria-label="edit"
            >
              <EditIcon />
            </IconButton>
            <IconButton
              onClick={() => {
                setSelectedProduct(product.id);
                handleOpen();
              }}
              aria-label="delete"
            >
              <DeleteIcon />
            </IconButton>
          </CardActions>
        )}
      </Box>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <Typography id="modal-modal-title" variant="h6" component="h2">
            Confirm Deletion Of Product!
          </Typography>
          <Typography id="modal-modal-description" sx={{ mt: 2 }}>
            Are you sure you want to delete the product?
          </Typography>
          <Box sx={{ marginTop: 5 }} display={"flex"} justifyContent={"right"}>
            <Button
              sx={{ backgroundColor: "#3f51b5", color: "white" }}
              size="small"
              onClick={async () => {
                const response = await fetch(
                  `http://localhost:8080/api/products/${selectedProduct}`,
                  {
                    method: "DELETE",
                    headers: {
                      "Content-Type": "application/json",
                      Authorization: "Bearer " + localStorage.getItem("token"),
                    },
                  }
                );
                if (response.ok) {
                  setOpen(false);
                  window.location.reload();
                  alert("Product Deleted");
                }
              }}
            >
              Delete
            </Button>
            <Button
              sx={{
                backgroundColor: "white",
                color: "#3f51b5",
                marginLeft: 2,
                border: "1px solid #3f51b5",
              }}
              size="small"
              onClick={() => setOpen(false)}
            >
              Close
            </Button>
          </Box>
        </Box>
      </Modal>
    </Card>
  );
}
