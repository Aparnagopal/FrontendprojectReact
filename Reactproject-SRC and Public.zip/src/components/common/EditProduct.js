import {
  Box,
  Button,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Typography,
} from "@mui/material";
import { useState } from "react";

const EditProduct = ({ setUseEdit, productToEdit }) => {
  const [name, setName] = useState(productToEdit.name);
  const [category, setCategory] = useState(productToEdit.category);
  const [manufacturer, setManufacturer] = useState(productToEdit.manufacturer);
  const [availableItems, setAvailableItems] = useState(
    productToEdit.availableItems
  );
  const [price, setPrice] = useState(productToEdit.price);
  const [description, setDescription] = useState(productToEdit.description);
  const [image, setImage] = useState(productToEdit.imageUrl);

  return (
    <Box
      display={"flex"}
      justifyContent={"center"}
      flexDirection={"column"}
      alignItems={"center"}
    >
      <Typography sx={{ marginTop: 4 }} fontSize={"1.2rem"}>
        Modify Product
      </Typography>
      <TextField
        margin="normal"
        required
        value={name}
        onChange={e => setName(e.target.value)}
        id="name"
        label="Name"
        name="name"
        sx={{ width: "100%", maxWidth: "500px" }}
      />
      <TextField
        margin="normal"
        value={category}
        onChange={e => setCategory(e.target.value)}
        required
        id="category"
        label="Category"
        name="category"
        sx={{ width: "100%", maxWidth: "500px" }}
      />

      <TextField
        margin="normal"
        required
        value={manufacturer}
        onChange={e => setManufacturer(e.target.value)}
        id="manufacturer"
        label="Manufacturer"
        name="manufacturer"
        sx={{ width: "100%", maxWidth: "500px" }}
      />
      <TextField
        margin="normal"
        required
        value={availableItems}
        onChange={e => setAvailableItems(e.target.value)}
        id="available-items"
        label="Available Items"
        sx={{ width: "100%", maxWidth: "500px" }}
        name="available-items"
      />
      <TextField
        margin="normal"
        required
        value={price}
        onChange={e => setPrice(e.target.value)}
        id="price"
        label="Price"
        sx={{ width: "100%", maxWidth: "500px" }}
        name="price"
        type="number"
      />
      <TextField
        margin="normal"
        required
        value={image}
        onChange={e => setImage(e.target.value)}
        id="image-url"
        label="Image URL"
        sx={{ width: "100%", maxWidth: "500px" }}
        name="image-url"
      />
      <TextField
        margin="normal"
        required
        value={description}
        onChange={e => setDescription(e.target.value)}
        id="product-description"
        label="Product Description"
        sx={{ width: "100%", maxWidth: "500px" }}
        name="product-description"
      />
      <Box sx={{ width: "100%", maxWidth: "500px" }} marginY={4}>
        <Button
          onClick={async () => {
            try {
              const response = await fetch(
                `http://localhost:8080/api/products/${productToEdit.id}`,
                {
                  method: "PUT",
                  headers: {
                    "Content-Type": "application/json",
                    Authorization: "Bearer " + localStorage.getItem("token"),
                  },
                  body: JSON.stringify({
                    name,
                    category,
                    manufacturer,
                    availableItems,
                    price,
                    description,
                    imageUrl: image,
                  }),
                }
              );
              if (!response.ok) {
                throw new Error("Something went wrong");
              }
              setUseEdit(false);
            } catch (error) {
              console.log(error);
            }
          }}
          variant="contained"
          sx={{ backgroundColor: "#3f51b5", width: "100%", maxWidth: "500px" }}
        >
          Modify Product
        </Button>
      </Box>
    </Box>
  );
};
export default EditProduct;
